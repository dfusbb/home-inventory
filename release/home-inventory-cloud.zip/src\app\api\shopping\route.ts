import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/activity";
import { requireVerifiedActor } from "@/lib/actor";

export async function GET() {
  const result = await requireVerifiedActor();
  if ("error" in result) return result.error;

  const items = await prisma.shoppingItem.findMany({
    where: { householdId: result.session.householdId },
    include: { product: true },
    orderBy: [{ isChecked: "asc" }, { createdAt: "desc" }],
  });

  return Response.json(items);
}

export async function POST(request: Request) {
  const result = await requireVerifiedActor();
  if ("error" in result) return result.error;

  const { name, quantity = 1, productId } = await request.json();
  if (!name?.trim()) {
    return Response.json({ error: "יש להזין שם פריט" }, { status: 400 });
  }

  const item = await prisma.shoppingItem.create({
    data: {
      name: name.trim(),
      quantity: Math.max(1, Number(quantity) || 1),
      productId: productId || null,
      householdId: result.session.householdId,
      addedBy: result.actorName,
    },
  });

  await logActivity(
    result.session.householdId,
    result.actorName,
    "הוספה לרשימת קניות",
    `כמות: ${item.quantity}`,
    item.name
  );

  return Response.json(item, { status: 201 });
}
