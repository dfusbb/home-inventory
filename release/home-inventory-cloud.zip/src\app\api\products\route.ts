import { prisma } from "@/lib/prisma";
import { requireVerifiedActor } from "@/lib/actor";

export async function GET() {
  const result = await requireVerifiedActor();
  if ("error" in result) return result.error;

  const products = await prisma.product.findMany({
    where: { householdId: result.session.householdId },
    orderBy: { name: "asc" },
  });

  return Response.json(products);
}

export async function POST(request: Request) {
  const result = await requireVerifiedActor();
  if ("error" in result) return result.error;

  const { name, quantity = 0 } = await request.json();
  if (!name?.trim()) {
    return Response.json({ error: "יש להזין שם מוצר" }, { status: 400 });
  }

  const product = await prisma.product.create({
    data: {
      name: name.trim(),
      quantity: Math.max(0, Number(quantity) || 0),
      householdId: result.session.householdId,
    },
  });

  const { logActivity } = await import("@/lib/activity");
  await logActivity(
    result.session.householdId,
    result.actorName,
    "הוספת מוצר",
    `כמות: ${product.quantity}`,
    product.name
  );

  return Response.json(product, { status: 201 });
}
