"use client";

import { useState } from "react";
import ImageEditorModal from "@/components/ImageEditorModal";

interface Product {
  id: string;
  name: string;
  quantity: number;
  imageUrl: string | null;
  isMissing: boolean;
}

interface ProductEditModalProps {
  product: Product;
  onClose: () => void;
  onUpdate: (product: Product) => void;
  onDelete: (id: string) => void;
}

export default function ProductEditModal({
  product,
  onClose,
  onUpdate,
  onDelete,
}: ProductEditModalProps) {
  const [name, setName] = useState(product.name);
  const [quantity, setQuantity] = useState(product.quantity);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [pendingImage, setPendingImage] = useState<File | null>(null);

  async function save(updates: Partial<Product>) {
    setLoading(true);
    try {
      const res = await fetch(`/api/products/${product.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      if (res.ok) {
        const updated = await res.json();
        onUpdate(updated);
      }
    } finally {
      setLoading(false);
    }
  }

  function handleImageSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setPendingImage(file);
    e.target.value = "";
  }

  async function uploadProcessedImage(blob: Blob) {
    setUploading(true);
    try {
      const ext = blob.type === "image/png" ? "png" : "jpg";
      const formData = new FormData();
      formData.append("image", blob, `product.${ext}`);
      const res = await fetch(`/api/products/${product.id}/image`, {
        method: "POST",
        body: formData,
      });
      if (res.ok) {
        const updated = await res.json();
        onUpdate(updated);
        setPendingImage(null);
      }
    } finally {
      setUploading(false);
    }
  }

  async function handleDelete() {
    if (!confirm("למחוק את המוצר?")) return;
    const res = await fetch(`/api/products/${product.id}`, { method: "DELETE" });
    if (res.ok) {
      onDelete(product.id);
      onClose();
    }
  }

  return (
    <>
      {pendingImage && (
        <ImageEditorModal
          file={pendingImage}
          onClose={() => setPendingImage(null)}
          onSave={uploadProcessedImage}
        />
      )}

      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm p-0 sm:p-4">
        <div className="bg-white rounded-t-2xl sm:rounded-2xl shadow-2xl w-full max-w-md p-6 animate-slide-up max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-lg font-bold">עריכת מוצר</h2>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200"
            >
              ✕
            </button>
          </div>

          <div className="flex justify-center mb-5">
            {product.imageUrl ? (
              <div className="w-28 h-28 rounded-xl border border-border bg-[repeating-conic-gradient(#e2e8f0_0%_25%,#f8fafc_0%_50%)] bg-[length:12px_12px] flex items-center justify-center overflow-hidden">
                <img
                  src={product.imageUrl}
                  alt={product.name}
                  className="w-full h-full object-contain"
                />
              </div>
            ) : (
              <div className="w-28 h-28 rounded-xl bg-slate-100 flex items-center justify-center text-3xl">
                📦
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-slate-600">שם מוצר</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full mt-1 px-3 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
            </div>

            <div>
              <label className="text-sm font-medium text-slate-600">כמות במלאי</label>
              <div className="flex items-center gap-3 mt-1">
                <button
                  onClick={() => setQuantity(Math.max(0, quantity - 1))}
                  className="w-10 h-10 rounded-xl bg-slate-100 font-bold text-lg hover:bg-slate-200"
                >
                  −
                </button>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(0, Number(e.target.value)))}
                  className="flex-1 text-center px-3 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/30 text-lg font-semibold"
                  min={0}
                />
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 rounded-xl bg-slate-100 font-bold text-lg hover:bg-slate-200"
                >
                  +
                </button>
              </div>
            </div>

            <label className="flex items-center justify-center gap-2 py-3 rounded-xl border-2 border-dashed border-border cursor-pointer hover:border-primary hover:bg-blue-50 transition">
              <span className="text-sm text-muted">
                {uploading ? "מעלה תמונה..." : "📷 צלם או בחר תמונה"}
              </span>
              <input
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={handleImageSelect}
                disabled={uploading}
              />
            </label>
            <p className="text-xs text-center text-muted -mt-2">
              אפשר לחתוך שוליים ולהסיר רקע כהה לפני השמירה
            </p>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => save({ name, quantity })}
                disabled={loading}
                className="flex-1 py-3 rounded-xl bg-primary text-white font-semibold hover:bg-[var(--primary-hover)] disabled:opacity-60"
              >
                {loading ? "שומר..." : "שמור"}
              </button>
              <button
                onClick={() => save({ isMissing: true })}
                disabled={loading}
                className="px-4 py-3 rounded-xl bg-orange-50 text-orange-600 font-medium hover:bg-orange-100 border border-orange-200"
              >
                חסר!
              </button>
            </div>

            <button
              onClick={handleDelete}
              className="w-full py-2.5 rounded-xl text-red-500 text-sm hover:bg-red-50"
            >
              מחק מוצר
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
