"use client";

import { useState } from "react";

interface ShoppingItem {
  id: string;
  name: string;
  quantity: number;
  isChecked: boolean;
  addedBy: string;
  createdAt: string;
}

interface ShoppingColumnProps {
  items: ShoppingItem[];
  onItemsChange: (items: ShoppingItem[]) => void;
}

export default function ShoppingColumn({ items, onItemsChange }: ShoppingColumnProps) {
  const [newName, setNewName] = useState("");
  const [showAdd, setShowAdd] = useState(false);

  const activeItems = items.filter((i) => !i.isChecked);
  const boughtItems = items.filter((i) => i.isChecked);

  async function addItem() {
    if (!newName.trim()) return;
    const res = await fetch("/api/shopping", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName.trim() }),
    });
    if (res.ok) {
      const item = await res.json();
      onItemsChange([item, ...items]);
      setNewName("");
      setShowAdd(false);
    }
  }

  async function toggleCheck(id: string, isChecked: boolean) {
    const res = await fetch(`/api/shopping/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isChecked }),
    });
    if (res.ok) {
      const updated = await res.json();
      onItemsChange(items.map((i) => (i.id === id ? updated : i)));
    }
  }

  async function removeItem(id: string) {
    const res = await fetch(`/api/shopping/${id}`, { method: "DELETE" });
    if (res.ok) {
      onItemsChange(items.filter((i) => i.id !== id));
    }
  }

  return (
    <div className="flex flex-col h-full bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
      <div className="px-5 py-4 border-b border-border bg-gradient-to-l from-orange-50 to-white">
        <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <span>🛍️</span> צריך לקנות
        </h2>
        <p className="text-xs text-muted mt-0.5">{activeItems.length} פריטים ברשימה</p>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {activeItems.length === 0 && (
          <div className="text-center py-12 text-muted">
            <div className="text-4xl mb-2">✅</div>
            <p className="text-sm">הכל במלאי!</p>
          </div>
        )}

        {activeItems.map((item) => (
          <div
            key={item.id}
            className="flex items-center gap-3 p-3 rounded-xl border border-border bg-white"
          >
            <button
              onClick={() => toggleCheck(item.id, true)}
              className="w-6 h-6 rounded-md border-2 border-slate-300 hover:border-primary hover:bg-blue-50 shrink-0 transition"
            />
            <div className="flex-1 min-w-0">
              <p className="font-medium text-slate-800">{item.name}</p>
              <p className="text-xs text-muted">נוסף ע&quot;י {item.addedBy}</p>
            </div>
            <span className="text-sm font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-lg">
              ×{item.quantity}
            </span>
            <button
              onClick={() => removeItem(item.id)}
              className="text-slate-400 hover:text-red-500 text-sm"
            >
              ✕
            </button>
          </div>
        ))}

        {boughtItems.length > 0 && (
          <div className="pt-3">
            <p className="text-xs text-muted px-1 mb-2">נרכשו לאחרונה</p>
            {boughtItems.slice(0, 5).map((item) => (
              <div
                key={item.id}
                className="flex items-center gap-3 p-2 rounded-lg opacity-50"
              >
                <span className="text-green-500 text-sm">✓</span>
                <p className="text-sm line-through text-slate-500">{item.name}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="p-3 border-t border-border">
        {showAdd ? (
          <div className="flex gap-2">
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="מה צריך לקנות?"
              className="flex-1 px-3 py-2.5 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/30 text-sm"
              autoFocus
              onKeyDown={(e) => e.key === "Enter" && addItem()}
            />
            <button
              onClick={addItem}
              className="px-4 py-2.5 rounded-xl bg-orange-500 text-white text-sm font-semibold"
            >
              הוסף
            </button>
            <button
              onClick={() => setShowAdd(false)}
              className="px-3 py-2.5 rounded-xl bg-slate-100 text-slate-500 text-sm"
            >
              ✕
            </button>
          </div>
        ) : (
          <button
            onClick={() => setShowAdd(true)}
            className="w-full py-3 rounded-xl bg-orange-500 text-white font-semibold hover:bg-orange-600 transition flex items-center justify-center gap-2"
          >
            <span className="text-lg">+</span> הוסף לרשימה
          </button>
        )}
      </div>
    </div>
  );
}
